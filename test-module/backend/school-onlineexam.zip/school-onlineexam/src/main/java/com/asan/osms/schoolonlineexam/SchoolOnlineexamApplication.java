package com.asan.osms.schoolonlineexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolOnlineexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolOnlineexamApplication.class, args);
	}

}
